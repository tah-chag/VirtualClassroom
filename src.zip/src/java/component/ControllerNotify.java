/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;

import component.schedule.Assignments;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import utils.LoginSession;

/**
 *
 * @author terence
 */
@Component
public class ControllerNotify extends LoginSession {

    private static final Logger LOG = Logger.getLogger(ControllerNotify.class.getName());

    @Autowired
    private Assignments assignments;
    //(cron="second, minute, hour, day, month, weekday")
    //The pattern is a list of six single space-separated fields: 
    //representing second, minute, hour, day, month, weekday.
    //Month and weekday names can be given as the first three letters of the English names.

    @Scheduled(cron = "30 * * * * *")
    public void atSchedule() {
        try {
            assignments.doTimerWork();
        } catch (InterruptedException ex) {
            LOG.log(Level.SEVERE, "Error InterruptedException in RealTimeJobsSchedulerTimer>>>{0}", ex.getMessage());
        }
    }
}
