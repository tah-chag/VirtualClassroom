/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component.schedule;

import config.DbConn;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;
import org.springframework.stereotype.Component;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Emails;

/**
 *
 * @author terence
 */
@Component
public class Assignments {

    @Autowired
    private DbConn conn;
    @Autowired
    private Emails email;

    private static final Logger LOG = Logger.getLogger(Assignments.class.getName());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public void doTimerWork() throws InterruptedException {
        if (!busy.compareAndSet(false, true)) {
            return;
        }
        try {
            LOG.log(Level.INFO, "RealTimeJobsSchedulerWorkerBean Timer work started :{0}", new Date());
            System.err.println("We are notifying");
            try {
                PreparedStatement ps = conn.getCon().prepareStatement("select * from student_course as c left join student as s on c.fk_student=s.reg_number left join assignment as a on a.fk_course=c.fk_course;");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    email.sendEmail(rs.getString("email"), "Hello Student, Assignment for "+rs.getString("fk_course")+" is due on " + rs.getString("due_date"), "Assignment due dates");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.closeConn();
            }
            //  repaymentsDao.repaymentsApplication(5,500);
        } catch (Exception err) {
            LOG.log(Level.SEVERE, "Error in RealTimeJobsSchedulerWorkerBean {0}", err.getMessage());
        } finally {
            busy.set(false);
            System.gc();
            LOG.log(Level.INFO, "RealTimeJobsSchedulerWorkerBean Timer work done");
            Thread.sleep(1000);
        }
    }
}
