/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package config;
//import com.mysql.jdbc.Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author tariro
 */

/*@Configuration
@ComponentScan(basePackages = { "zw.co.cafca.*" })
@PropertySource("classpath:classes/zw/co/cafca/config/cafca.properties", ignoreResourceNotFound=true)*/
//@ActiveProfiles(profiles = "dev")
//@ContextConfiguration("classpath:spring-web-servlet.xml")
@Repository
@Transactional
public class DbConn {

    //@Value("${url}")
    //private String mongodbUrl;
    private Connection con;

    @Autowired
    ServletContext context;

    @Autowired
    private PropertiesDB properties;

    public Connection getCon() {
        try {
            Class.forName(properties.getDriver());
            con = DriverManager.getConnection(properties.getUrl(),
                    properties.getUser(), properties.getPassword());
        } catch (Exception e) {
            System.err.println("Config file not found.");
            e.printStackTrace();
        }
        /*try {
         con.setTransactionIsolation(TRANSACTION_READ_UNCOMMITTED);
         } catch (SQLException ex) {
         Logger.getLogger(DbConn.class.getName()).log(Level.SEVERE, null, ex);
         }*/
        return con;
    }

    public void closeConn() {
        /*try {
         con.setTransactionIsolation(TRANSACTION_REPEATABLE_READ);
         } catch (SQLException ex) {
         Logger.getLogger(DbConn.class.getName()).log(Level.SEVERE, null, ex);
         }
         */
        try {
            con.close();
        } catch (Exception e) {
            // e.printStackTrace();
        }
    }

    public void setCon(Connection conn) {
        this.con = conn;
    }

}
