/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author tariro
 */
public interface IMessage {

    final String TITLE = "title";

    final String MESSAGE = "message";
    final String MESSAGE_SUCCESS = "Data has been successfully saved.";
    final String MESSAGE_FAILED = "Network err. Data not saved. Try again.";
    final String REG_SUCCESS = "Registration successful. Kindly check your email for login credentials";
    final String REG_FAILED = "Registration failed, account already exists. Contact adminstration for account recovery.";

    final String LOGGED_AUTH = "logged_auth";
    final String LOGED_USER_ID = "logged_user_id";

    final String LOGGED_STATION = "logged_station";
    final String LOGGED_BEANUSER = "logged_user";
    final String LOGED_USER = "logged_user_name";
    final String LOGED_USER_POSITION = "logged_user_position";
}
