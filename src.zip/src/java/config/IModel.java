/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author tariro
 */
public interface IModel {

    final String MODEL_CHANGEPASSWORD = "changepassword";
    final String MODEL_CLASS2 = "application/class2";
    final String MODEL_LECTURER = "lecturer/index";
    final String MODEL_ACCOUNTS_SUMMARY = "accounts/summary";
    final String MODEL_APPLICATION_STATUS = "application/status";
    final String MODEL_APPLICATION_VIEW = "application/view";
    final String MODEL_APPLICATIONS = "application/index";
    final String MODEL_APPLICATION_LIST = "application/list";
    final String MODEL_APPLICATION_EDIT = "application/edit";
    final String MODEL_CONTACTS = "contact/index";
    final String MODEL_DELIVERY = "gmb/delivery";
    final String MODEL_DELIVERY_PRICE = "gmb/price";
    final String MODEL_DISTRICT = "region/district";
    final String MODEL_FARMER_EDIT = "farmer/edit";
    final String MODEL_FARMER_SEARCH = "farmer/search";
    final String MODEL_COURSE_EDIT = "course/edit";
    final String MODEL_FARMERS = "farmer/index";
    final String MODEL_ASSIGNMENTS = "coursework/assignments";
    final String MODEL_MARKS = "coursework/marks";
    final String MODEL_HOME = "index";
    final String MODEL_LOGIN = "login";
    final String MODEL_OVERRIDE = "application/override";
    final String MODEL_NOTES = "coursework/notes";
    final String MODEL_REPORT = "reports/index";
    final String MODEL_SEARCH = "search/child";
    final String MODEL_REGISTER_STUDENT = "register_student";
    final String MODEL_REGISTER_LECTURER = "register_lecturer";
    final String MODEL_INPUTS = "input/index";
    final String MODEL_INPUTS_PRICE = "input/price";
    final String MODEL_INPUTS_RATES = "input/rates";
    final String MODEL_PROGRAM = "program/index";
    final String MODEL_RECORDS = "application/record";
    final String MODEL_STUDENT = "student/index";
    final String MODEL_MYCOURSES = "courselist/index";
    final String MODEL_USERS = "users/index";
    final String MODEL_NOT_FOUND = "notfound";
    final String MODEL_DELETE = "deleteconfirm";

}
