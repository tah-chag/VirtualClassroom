/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author tariro
 */
public interface ITable {

    final String TBL_APPLICATION = "application";
    final String TBL_APPLICATION_RECORD = "application_record";
    final String TBL_STOCK_TRANS = "stock_trans";
    final String TBL_CONTACT = "contact";
    final String TBL_CONTACT_TYPE = "contact_type";
    final String TBL_COURSE = "course";
    final String TBL_DESIGNATION = "designation";
    final String TBL_LECTURE = "lecture";
    final String TBL_LECTURER_COURSE = "lecturer_course";
    final String TBL_LECTURER = "lecturer";
    final String TBL_STUDENT_COURSE = "student_course";
    final String TBL_LOGIN = "sys_login";
    final String TBL_PROGR = "programme";
    final String TBL_NOTES = "notes";
    final String TBL_QUESTION = "question";
    final String TBL_PRICE_INPUT = "price_input";
    final String TBL_PRICE_SCHEME = "price_disbursement";
    final String TBL_PRODUCT = "product_";
    final String TBL_ASSIGNMENT = "assignment";
    final String TBL_RECORD_TYPE = "record_type";
    final String TBL_SEASON = "season";
    final String TBL_ASSIGNMENT_STUDENT = "assignment_student";
    final String TBL_STUDENT = "student";
    final String TBL_USER = "sys_user";
    final String TBL_WARD = "ward";
    final String VW_APPLICATION = "vw_application";
    final String VW_COMPOUNDS = "VW_COMPOUND";
    final String VW_CATEGORY = "vw_cat";
}
