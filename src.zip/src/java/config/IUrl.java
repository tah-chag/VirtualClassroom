/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author tariro
 */
public interface IUrl {

    final String URL_DOCS = "/docs/{type}/{id}";
    final String LNK_DOCS = "/docs/";
    
    final String URL_MYCOURSES = "/mycourses";
    
    final String url_lookup = "/lookup/{et}/{search}";
    final String LNK_SEARCH = "/lookup/";
    final String URL_HOME = "/";
    final String URL_CHANGE_PASSWORD = "/changepassword";
    final String URL_LOGIN = "/login";
    final String URL_LOGOUT = "/logout";
    final String URL_PASSWORD_RECOVER = "/recoverpassword";

    final String URL_TEST = "/test";
    final String URL_TEST_ACTION = URL_TEST + "/{action}";

    final String URL_LECTURERS = "/lecturer";
    final String URL_LECTURE = "/lecture";
    final String URL_LECTURE_ACTION_ID = URL_LECTURE + "/{action}/{id}";
    final String LNK_LECTURE_ATTEND = URL_LECTURE + "/attend/";

    final String URL_APPLICATION_CLASS2 = URL_LECTURERS + "/class2";
    final String URL_APPLICATION_DISBURSEMENTS = URL_LECTURERS + "/disbursements";
    final String URL_APPLICATION_FARM_RECORDS = URL_LECTURERS + "/farmrecords";

    final String URL_APPLICATION_CONTRACT = URL_LECTURERS + "/contract";
    final String URL_APPLICATION_VERIFY = URL_LECTURERS + "/verify";

    //final String URL_APPLICATION_ACTION = URL_LECTURERS + "/{action}";
    final String URL_APPLICATION_ACTION_ID = URL_LECTURERS + "/{action}/{id}";
    final String URL_APPLICATION_EDIT = URL_LECTURERS + "/edit/";
    final String URL_APPLICATION_RECORDS = URL_LECTURERS + "/records/";
    final String URL_APPLICATION_STATUS = URL_LECTURERS + "/status/";
    final String URL_APPLICATION_OVERRIDE = URL_LECTURERS + "/override/";
    final String URL_APPLICATION_VIEW = URL_LECTURERS + "/view/";

    final String URL_COURSE = "/course";
    final String URL_COURSE_ACTION_ID = URL_COURSE + "/{action}/{id}";
    final String URL_FARMER_CONTACT = URL_COURSE + "contact/";
    final String URL_FARMER_APPLICATION = URL_COURSE + "application/";
    final String URL_COURSE_DELETE = URL_COURSE + "/delete/";
    final String URL_COURSE_EDIT = URL_COURSE + "/edit/";
    final String URL_FARMER_PLOT = URL_COURSE + "plot/";
    final String URL_FARMER_VIEW = URL_COURSE + "view/";

    final String URL_FARMER_ADD = "/farmer/add";
    final String URL_FARMER_SEARCH = "/farmer/search";
    final String URL_FARMER_CONTACT_ADD = "/farmer/contactadd";

    final String URL_INPUTS = "/inputs";
    final String URL_INPUTS_ACTION = URL_INPUTS + "/{action}";
    final String LNK_INPUTS_PRICE = URL_INPUTS + "/price";
    final String LNK_INPUTS_RATES = URL_INPUTS + "/rates";
    final String LNK_INPUTS_TYPES = URL_INPUTS + "/types";

    final String URL_PROGRAMS = "/programs";
    final String URL_PROGRAMS_ACTION_ID = URL_PROGRAMS + "/{action}/{id}";
    final String LNK_PROGRAM_EDIT = URL_PROGRAMS + "/edit/";
    final String LNK_PROGRAM_DELETE = URL_PROGRAMS + "/delete/";

    final String URL_DISTRICT = "/district/";
    final String URL_DISTRICT_ACTION_ID = URL_DISTRICT + "{action}/{id}";
    final String LNK_DISTRICT_WARD = URL_DISTRICT + "ward/";

    final String URL_STUDENT = "/student";
    final String URL_SCHEME_ACTION_ID = URL_STUDENT + "/{action}/{id}";
    final String URL_STOCK_DRUM_ID_MACHINE_USERS = URL_STUDENT + "{id}/{machine}/users";
    final String LNK_SCHEME_INPUTS = URL_STUDENT + "/inputs/";

    final String URL_NOTES = "/notes";
    final String URL_REGISTER_LECTURER = "/registerlecturer";
    final String URL_REGISTER_STUDENT = "/registerstudent";
    final String URL_RECEIPTS = "/receipts/";
    final String URL_RECEIPTS_TYPE_ID = URL_RECEIPTS + "{type}/{id}";
    final String URL_RECEIPTS_PREVIEW = URL_RECEIPTS + "preview/{type}/{id}";
    final String LNK_RECEIPT_PREVIEW = URL_RECEIPTS + "preview/";

    final String URL_COURSEWORK = "/coursework/{action}";
    final String LNK_COURSEWORK = "/coursework/";
    final String LNK_ASSIGNMENTS = LNK_COURSEWORK + "assignments";
    final String LNK_MARKS = LNK_COURSEWORK + "marks";
    final String LNK_NOTES = LNK_COURSEWORK + "notes";
    final String URL_STOCK_TAKE_ID = URL_COURSEWORK + "{id}";
    final String URL_STOCK_TAKE_ID_MACHINE = URL_COURSEWORK + "{id}/{machine}";
    final String URL_STOCK_TAKE_ID_MACHINE_USERS = URL_COURSEWORK + "{id}/{machine}/users";

    final String URL_STOCK_EDIT = "/edit/{id}";

    final String URL_REPORTS = "/report/{name}";
    final String LNK_REPORT = "/report/";

    final String RPT_WIP_FACTORY = LNK_REPORT + "wip_factory";
    final String RPT_WIP_SUMMARY = LNK_REPORT + "wip_summary";
    final String RPT_WIP_SUMMARY_MACHINE = LNK_REPORT + "wip_summary_machine";
    final String RPT_WIP_OTHER = LNK_REPORT + "wip_other";

    final String URL_SETTINGS = "/settings/{action}";
    final String LNK_SETTINGS = "/settings/";
    final String SETTINGS_MACHINES = LNK_SETTINGS + "machines";
    final String SETTINGS_GMB = LNK_SETTINGS + "gmb";
    final String SETTINGS_USERS = LNK_SETTINGS + "users";
    final String SETTINGS_SEASONS = LNK_SETTINGS + "seasons";
    final String SETTINGS_SCHEME = LNK_SETTINGS + "scheme";
    final String SETTINGS_PRODUCTS = LNK_SETTINGS + "products";
    final String SETTINGS_PRODUCTS_OTK = LNK_SETTINGS + "productsotk";
    final String SETTINGS_MATERIALS = LNK_SETTINGS + "materials";

    final String URL_SERVICE = "/service/";
    final String URL_SERVICE_USERS_GET = URL_SERVICE + "users";
    final String URL_SERVICE_PRODUCTS = URL_SERVICE + "products";

    final String URL_SERVICE_CONTRACT = URL_SERVICE + "/contract";
    final String LNK_SERVICE_CONTRACT = URL_SERVICE + "/contract";
    final String LNK_SERVICE_IR = URL_SERVICE + "/ir";

    final String UPLOADED_FOLDER = "d://stocktake//";
    // final String URL_SERVICE_PRODUCTS_SEARCH=URL_SERVICE+"products/{search}";
}
