/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 *
 * @author tariro
 */
@Configuration
//@ComponentScan(basePackages = {"co.zw.cafca.*"})
@PropertySource("classpath:config.properties")
public class PropertiesCon {

    @Value("assignments")
    private String assignment;
    @Value("lectures")
    private String lectures;

    /**
     * @return the assignment
     */
    public String getAssignment() {
        return assignment;
    }

    /**
     * @param assignment the assignment to set
     */
    public void setAssignment(String assignment) {
        this.assignment = assignment;
    }

    /**
     * @return the lectures
     */
    public String getLectures() {
        return lectures;
    }

    /**
     * @param lectures the lectures to set
     */
    public void setLectures(String lectures) {
        this.lectures = lectures;
    }

}
