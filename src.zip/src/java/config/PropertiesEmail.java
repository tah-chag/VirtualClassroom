/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 *
 * @author terence
 */
@Configuration
@PropertySource("classpath:email.properties")
public class PropertiesEmail {

    @Value("${emailuser}")
    private String emailuser;
    @Value("${emailpassword}")
    private String emailpassword;
    @Value("${socketFactory.port}")
    private String socketFactory_port;
    @Value("${smtp.host}")
    private String smtp_host;
    @Value("${smtp.port}")
    private String smtp_port;

    /**
     * @return the emailuser
     */
    public String getEmailuser() {
        return emailuser;
    }

    /**
     * @param emailuser the emailuser to set
     */
    public void setEmailuser(String emailuser) {
        this.emailuser = emailuser;
    }

    /**
     * @return the emailpassword
     */
    public String getEmailpassword() {
        return emailpassword;
    }

    /**
     * @param emailpassword the emailpassword to set
     */
    public void setEmailpassword(String emailpassword) {
        this.emailpassword = emailpassword;
    }

    /**
     * @return the socketFactory_port
     */
    public String getSocketFactory_port() {
        return socketFactory_port;
    }

    /**
     * @param socketFactory_port the socketFactory_port to set
     */
    public void setSocketFactory_port(String socketFactory_port) {
        this.socketFactory_port = socketFactory_port;
    }

    /**
     * @return the smtp_host
     */
    public String getSmtp_host() {
        return smtp_host;
    }

    /**
     * @param smtp_host the smtp_host to set
     */
    public void setSmtp_host(String smtp_host) {
        this.smtp_host = smtp_host;
    }

    /**
     * @return the smtp_port
     */
    public String getSmtp_port() {
        return smtp_port;
    }

    /**
     * @param smtp_port the smtp_port to set
     */
    public void setSmtp_port(String smtp_port) {
        this.smtp_port = smtp_port;
    }

}
