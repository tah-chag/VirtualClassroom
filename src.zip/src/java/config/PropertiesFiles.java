/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 *
 * @author terence
 */
@Configuration
@PropertySource("classpath:filepaths.properties")
public class PropertiesFiles {

    @Value("${assignment}")
    private String assignment;
    @Value("${student_assignment}")
    private String student_assignment;
    @Value("${lecture}")
    private String lecture;

    @Value("${notes}")
    private String notes;

    /**
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * @param notes the notes to set
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

    /**
     * @return the assignment
     */
    public String getAssignment() {
        return assignment;
    }

    /**
     * @param assignment the assignment to set
     */
    public void setAssignment(String assignment) {
        this.assignment = assignment;
    }

    /**
     * @return the lecture
     */
    public String getLecture() {
        return lecture;
    }

    /**
     * @param lecture the lecture to set
     */
    public void setLecture(String lecture) {
        this.lecture = lecture;
    }

    /**
     * @return the student_assignment
     */
    public String getStudent_assignment() {
        return student_assignment;
    }

    /**
     * @param student_assignment the student_assignment to set
     */
    public void setStudent_assignment(String student_assignment) {
        this.student_assignment = student_assignment;
    }
}
