/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import javax.servlet.http.HttpServletRequest;
import model.BeanCourse;
import model.BeanDelete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServiceCourse;
import utils.LoginSession;

/**
 *
 * @author terence
 */
@Controller
public class ControllerCourse extends LoginSession {

    @Autowired
    @Qualifier("ServiceCourse")
    private ServiceCourse servicecource;

    @RequestMapping(value = URL_COURSE, method = RequestMethod.GET)
    public String showCourses(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Course");
        model.addAttribute("courses", servicecource.getCourses());
        model.addAttribute("c", new BeanCourse());
        return "course/index";
    }

    @RequestMapping(value = URL_COURSE, method = RequestMethod.POST)
    public String POSTshowCourses(Model model, HttpServletRequest request,
            @ModelAttribute("c") BeanCourse c) {
        setSession(model, request);
        model.addAttribute(TITLE, "Course");
        boolean f = servicecource.addCourse(c);
        model.addAttribute("courses", servicecource.getCourses());
        model.addAttribute("c", new BeanCourse());
        return "course/index";
    }

    @RequestMapping(value = URL_COURSE_ACTION_ID, method = RequestMethod.GET)
    public String courseAction(@PathVariable("action") String action, @PathVariable("id") String id, Model model, HttpServletRequest request) {
        switch (action) {
            case "edit":
                model.addAttribute(TITLE, "Edit Course");
                model.addAttribute("course", servicecource.getCourse(id));
                return MODEL_COURSE_EDIT;
            case "delete":
                BeanDelete d = new BeanDelete();
                d.setStrid(id);
                model.addAttribute("delete", d);
                return MODEL_DELETE;
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = URL_COURSE_ACTION_ID, method = RequestMethod.POST)
    public String POSTcourseAction(@PathVariable("action") String action, @PathVariable("id") String id, Model model, HttpServletRequest request) {
        switch (action) {
            case "edit":
                model.addAttribute(TITLE, "Edit Course");
                model.addAttribute("course", servicecource.getCourse(id));
                return MODEL_COURSE_EDIT;
            case "delete":
                BeanDelete d = new BeanDelete();
                d.setStrid(id);
                model.addAttribute("delete", d);
                return MODEL_DELETE;
             default:
                return MODEL_NOT_FOUND;
        }

    }
}
