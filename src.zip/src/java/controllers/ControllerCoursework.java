/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.servlet.http.HttpServletRequest;
import model.BeanAssignment;
import model.BeanAssignmentStudent;
import model.BeanNotes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServiceAssignment;
import services.ServiceCourse;
import services.ServiceCourseWork;
import services.ServiceNotes;
import utils.LoginSession;

/**
 *
 * @author tariro
 */
@Controller
public class ControllerCoursework extends LoginSession {

    @Autowired
    @Qualifier("ServiceAssignment")
    private ServiceAssignment serviceassignment;

    @Autowired
    @Qualifier("ServiceCourseWork")
    private ServiceCourseWork servicecoursework;

    @Autowired
    @Qualifier("ServiceNotes")
    private ServiceNotes servicenotes;

    @Autowired
    @Qualifier("ServiceCourse")
    private ServiceCourse servicecourse;

    @RequestMapping(value = URL_COURSEWORK, method = RequestMethod.GET)
    public String showAction(@PathVariable("action") String action,
            Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, action.toUpperCase());
        model.addAttribute("courses", servicecourse.getCourses(loggedlogin));
        switch (action) {
            case "assignments":
                model.addAttribute("assignment", new BeanAssignment());
                BeanAssignmentStudent sa = new BeanAssignmentStudent();
                sa.setFk_student(loggedlogin.getFk_user());
                model.addAttribute("sa", sa);
                model.addAttribute("assignments", serviceassignment.getAssignments(loggedlogin));
                model.addAttribute("sassignments", loggedlogin.getFk_user_type() == 2 ? serviceassignment.getStudentAssignments(loggedlogin.getFk_user()) : serviceassignment.getStudentAssignments(loggedlogin));
                return MODEL_ASSIGNMENTS;
            case "marks":
                return MODEL_MARKS;
            case "notes":
                model.addAttribute("note", new BeanNotes());
                model.addAttribute("notes", servicenotes.getNotes());
                return MODEL_NOTES;
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = URL_COURSEWORK, method = RequestMethod.POST)
    public String POSTshowAction(@PathVariable("action") String action,
            @ModelAttribute("assignment") BeanAssignment assignment,
            @ModelAttribute("note") BeanNotes note,
            Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, action.toUpperCase());
        model.addAttribute("courses", servicecourse.getCourses(loggedlogin));
        boolean f = false;
        switch (action) {
            case "assignments":
                assignment.setFk_created_by(loggedlogin.getFk_user());
                f = serviceassignment.addAssignment(assignment);
                BeanAssignment n1 = serviceassignment.getAssignment(assignment);
                if (note.getFile().isEmpty()) {
                    //continue;
                } else {
                    try {
                        byte[] bytes = note.getFile().getBytes();
                        Path path = Paths.get(case_files.getAssignment() + n1.getId() + ".pdf");
                        Files.write(path, bytes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                BeanAssignmentStudent sa = new BeanAssignmentStudent();
                sa.setFk_student(loggedlogin.getFk_user());
                model.addAttribute("sa", sa);
                model.addAttribute("assignments", serviceassignment.getAssignments(loggedlogin));
                model.addAttribute("sassignments", loggedlogin.getFk_user_type() == 2 ? serviceassignment.getStudentAssignments(loggedlogin.getFk_user()) : serviceassignment.getStudentAssignments(loggedlogin));
                model.addAttribute("assignment", new BeanAssignment());
                model.addAttribute(MESSAGE, f ? MESSAGE_SUCCESS : MESSAGE_FAILED);
                return MODEL_ASSIGNMENTS;
            case "marks":
                return MODEL_MARKS;
            case "notes":
                note.setFk_created_by(loggedlogin.getFk_user());
                f = servicenotes.addNotes(note);
                BeanNotes n = servicenotes.getNote(note);
                if (note.getFile().isEmpty()) {
                    //continue;
                } else {
                    try {
                        byte[] bytes = note.getFile().getBytes();
                        Path path = Paths.get(case_files.getNotes() + n.getId() + ".pdf");
                        Files.write(path, bytes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                model.addAttribute("note", new BeanNotes());
                model.addAttribute("notes", servicenotes.getNotes());
                model.addAttribute(MESSAGE, f ? MESSAGE_SUCCESS : MESSAGE_FAILED);
                return MODEL_NOTES;
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = "/uploadassignment", method = RequestMethod.POST)
    public String uploadAssignment(Model model, HttpServletRequest request,
            @ModelAttribute("sa") BeanAssignmentStudent sa) {
        setSession(model, request);
        boolean f = serviceassignment.addStudentAssignment(sa);
        BeanAssignmentStudent ss = serviceassignment.getStudentAssignment(sa);
        if (sa.getFile().isEmpty()) {
            //continue;
        } else {
            try {
                byte[] bytes = sa.getFile().getBytes();
                Path path = Paths.get(case_files.getStudent_assignment() + ss.getId() + ".pdf");
                Files.write(path, bytes);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        model.addAttribute(TITLE, "Assignemts");
        model.addAttribute("assignment", new BeanAssignment());
        sa = new BeanAssignmentStudent();
        sa.setFk_student(loggedUser.getFk_user());
        model.addAttribute("sa", sa);
        //  model.addAttribute("assignments", serviceassignment.getAssignments());
        model.addAttribute("sassignments", serviceassignment.getStudentAssignments());
        model.addAttribute(MESSAGE, f ? MESSAGE_SUCCESS : MESSAGE_FAILED);
        return MODEL_ASSIGNMENTS;
    }
}
