/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import config.IModel;
import config.IUrl;
import javax.servlet.http.HttpServletRequest;
import model.BeanLogin;
import org.springframework.ui.Model;
import utils.LoginSession;

/**
 *
 * @author tariro
 */
@Controller
public class ControllerHome extends LoginSession {

    @RequestMapping(value = {"", "/"}, method = RequestMethod.GET)
    public String showHOme(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Home");
        return MODEL_HOME;
    }
    /*@RequestMapping(value = {URL_LOGIN}, method = RequestMethod.GET)
    public String showLogin(Model model) {
        model.addAttribute("message", "");
        model.addAttribute("login", new BeanLogin());
        return MODEL_LOGIN;
    }*/
}
