/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import javax.servlet.http.HttpServletRequest;
import model.BeanLecture;
import model.BeanLectureQuestion;
import model.BeanSelector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServiceCourse;
import services.ServiceLecture;
import services.ServiceLecturer;
import utils.LoginSession;

/**
 *
 * @author tariro
 */
@Controller
public class ControllerLecture extends LoginSession {

    @Autowired
    @Qualifier("ServiceCourse")
    private ServiceCourse servicecource;
    @Autowired
    @Qualifier("ServiceLecturer")
    private ServiceLecturer servicelecturer;

    @Autowired
    @Qualifier("ServiceLecture")
    private ServiceLecture servicelecture;

    @RequestMapping(value = URL_LECTURE, method = RequestMethod.GET)
    public String showlectures(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Lectures");
        BeanLecture l = new BeanLecture();
        model.addAttribute("lecture", l);
        model.addAttribute("select", new BeanSelector());
        model.addAttribute("courses", servicecource.getCourses(loggedlogin));
        model.addAttribute("lectures", servicelecture.getLectures(loggedlogin));
        return "lecture/index";
    }

    @RequestMapping(value = URL_LECTURE, method = RequestMethod.POST)
    public String POSTshowlectures(@ModelAttribute("lecture") BeanLecture l, Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Lectures");
        boolean f = servicelecture.addLecture(l);
        l = new BeanLecture();
        model.addAttribute("lecture", l);
        model.addAttribute("select", new BeanSelector());
        model.addAttribute("courses", servicecource.getCourses(loggedlogin));
        model.addAttribute("lectures", servicelecture.getLectures(loggedlogin));
        return "lecture/index";
    }

    @RequestMapping(value = URL_LECTURE_ACTION_ID, method = RequestMethod.GET)
    public String showActions(@PathVariable("action") String action, @PathVariable("id") int id,
            Model model, HttpServletRequest request) {
        setSession(model, request);
        switch (action) {
            case "attend":
                model.addAttribute("l", servicelecture.getLecture(id));
                BeanLectureQuestion k = new BeanLectureQuestion();
                k.setFk_lecture(id);
                k.setFk_student(loggedlogin.getFk_user());
                model.addAttribute("lecturequestion", k);

                return "lecture/attend";
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = "/lquestion", method = RequestMethod.POST)
    public String sendQuestion(@ModelAttribute("lecturequestion") BeanLectureQuestion l,
            Model model, HttpServletRequest request) {
        model.addAttribute("l", servicelecture.getLecture(l.getFk_lecture()));
        BeanLectureQuestion k = new BeanLectureQuestion();
        k.setFk_lecture(l.getFk_lecture());
        k.setFk_student(loggedlogin.getFk_user());
        return "lecture/attend";
    }
}
