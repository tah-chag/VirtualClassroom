/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import model.BeanLecturer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import services.ServiceLecturer;
import utils.LoginSession;

/**
 *
 * @author tariro
 */
@Controller
public class ControllerLecturer extends LoginSession {

    @Autowired
    @Qualifier("ServiceLecturer")
    private ServiceLecturer servicelecturer;

    @RequestMapping(value = URL_LECTURERS, method = RequestMethod.GET)
    public String showLectures(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Lecturers");
        model.addAttribute("lecturer", new BeanLecturer());
        model.addAttribute("lecturers", servicelecturer.getLecturers());
        return MODEL_LECTURER;
    }

    @RequestMapping(value = URL_LECTURERS, method = RequestMethod.POST)
    public String POSTshowLectures(Model model, HttpServletRequest request, @ModelAttribute("lecturer") BeanLecturer l) {
        setSession(model, request);
        boolean f = servicelecturer.addLecturer(l);
        model.addAttribute(TITLE, "Lecturers");
        model.addAttribute("lecturer", new BeanLecturer());
        model.addAttribute("lecturers", servicelecturer.getLecturers());
        return MODEL_LECTURER;
    }

}
