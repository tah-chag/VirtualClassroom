/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import utils.LoginSession;

/**
 *
 * @author terence
 */
@Controller
public class ControllerMaterial extends LoginSession {

    @RequestMapping(value = URL_NOTES, method = RequestMethod.GET)
    public String showMaterial(Model model) {
        return "notes/index";
    }

    @RequestMapping(value = URL_NOTES, method = RequestMethod.POST)
    public String POSTshowMaterial(Model model) {
        return "notes/index";
    }
}
