/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import javax.servlet.http.HttpServletRequest;
import model.BeanProgram;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServiceProgram;
import utils.LoginSession;

/**
 *
 * @author tariro
 */
@Controller
public class ControllerProgram extends LoginSession {

    @Autowired
    @Qualifier("ServiceProgram")
    private ServiceProgram serviceprogram;

    @RequestMapping(value = URL_PROGRAMS, method = RequestMethod.GET)
    public String showProgramms(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Programs");
        model.addAttribute("prog", new BeanProgram());
        model.addAttribute("programs", serviceprogram.getPrograms());
        return MODEL_PROGRAM;
    }

    @RequestMapping(value = URL_PROGRAMS, method = RequestMethod.POST)
    public String POSTshowProgramms(@ModelAttribute("prog") BeanProgram p,
            Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Programs");
        boolean f = serviceprogram.addProgram(p);
        model.addAttribute(TITLE, "Programs");
        model.addAttribute("prog", new BeanProgram());
        model.addAttribute("programs", serviceprogram.getPrograms());
        model.addAttribute(MESSAGE, f ? MESSAGE_SUCCESS : MESSAGE_FAILED);
        return MODEL_PROGRAM;
    }

    @RequestMapping(value = URL_PROGRAMS_ACTION_ID, method = RequestMethod.GET)
    public String actionProgram(@PathVariable("action") String action, Model model, HttpServletRequest request) {
        switch (action) {
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = URL_PROGRAMS_ACTION_ID, method = RequestMethod.POST)
    public String POSTactionProgram(@PathVariable("action") String action, Model model, HttpServletRequest request) {
        switch (action) {
            default:
                return MODEL_NOT_FOUND;
        }
    }

}
