/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import config.IMessage;
import config.IModel;
import static config.IModel.MODEL_HOME;
import static config.IModel.MODEL_LOGIN;
import static config.IModel.MODEL_NOT_FOUND;
import static config.IModel.MODEL_USERS;
import config.IUrl;
import static config.IUrl.URL_LOGIN;
import static config.IUrl.URL_SETTINGS;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import model.BeanCourse;
import model.BeanCourseList;
import model.BeanLecturer;
import model.BeanLogin;
import model.BeanPasswordChange;
import model.BeanStudent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServiceCourse;
import services.ServiceLecturer;
import services.ServiceLecturerCourse;
import services.ServiceSettings;
import services.ServiceStudent;
import services.ServiceStudentCourse;
import utils.Emails;
import utils.LoginSession;

/**
 *
 * @author tariro
 */
@Controller
public class ControllerSettings extends LoginSession implements IUrl, IModel, IMessage {

    @Autowired
    private Emails email;

    @Autowired
    @Qualifier("ServiceCourse")
    private ServiceCourse servicecourse;
    @Autowired
    @Qualifier("ServiceSettings")
    private ServiceSettings servicesettings;

    @Autowired
    @Qualifier("ServiceStudent")
    private ServiceStudent servicestudent;
    @Autowired
    @Qualifier("ServiceStudentCourse")
    private ServiceStudentCourse servicestudentcourse;
    @Autowired
    @Qualifier("ServiceLecturer")
    private ServiceLecturer servicelecturer;
    @Autowired
    @Qualifier("ServiceLecturerCourse")
    private ServiceLecturerCourse servicelecturercourse;

    @RequestMapping(value = URL_MYCOURSES, method = RequestMethod.GET)
    public String myCourses(Model model, HttpServletRequest request) {
        model.addAttribute(TITLE, "My Courses");
        return MODEL_MYCOURSES;
    }

    @RequestMapping(value = URL_MYCOURSES, method = RequestMethod.POST)
    public String POSTmyCourses(Model model, HttpServletRequest request) {
        model.addAttribute(TITLE, "My Courses");
        return MODEL_MYCOURSES;
    }

    @RequestMapping(value = URL_REGISTER_LECTURER, method = RequestMethod.GET)
    public String registerLect(Model model, HttpServletRequest request) {
        model.addAttribute(TITLE, "Registration Lecturer");
        BeanLecturer l = new BeanLecturer();
        List<BeanCourseList> lcl = new ArrayList<>();
        List<BeanCourse> lc = servicecourse.getCourses();
        int y = 0;
        for (BeanCourse c : lc) {
            BeanCourseList cl = new BeanCourseList();
            cl.setId(y);
            cl.setCourse(c);
            cl.setFk_course(c.getCourse_code());
            lcl.add(cl);
            y++;
        }
        l.setCourse_list(lcl);
        model.addAttribute("lecturer", l);
        model.addAttribute("ccouunt", servicecourse.getCount());
        return MODEL_REGISTER_LECTURER;
    }

    @RequestMapping(value = URL_REGISTER_LECTURER, method = RequestMethod.POST)
    public String POSTregisterLect(Model model,
            HttpServletRequest request, @ModelAttribute("lecturer") BeanLecturer l) {
        model.addAttribute(TITLE, "Registration Lecturer");
        boolean f = servicelecturer.addLecturer(l);
        if (f) {
            f = servicelecturercourse.addLectureCourse(l.getCourse_list(), l.getEc_number());
        }
        if (f) {
            email.sendEmail(l.getEmail(), "Hi " + l.getFirst_name().toUpperCase() + " , Please login with your EC number. Your password is password", "Virtual Classroom Account registration");
        }
        model.addAttribute(MESSAGE, f ? REG_SUCCESS : REG_FAILED);
        model.addAttribute("lecturer", new BeanLecturer());
        return MODEL_REGISTER_LECTURER;
    }

    @RequestMapping(value = URL_REGISTER_STUDENT, method = RequestMethod.GET)
    public String registerStudent(Model model) {
        model.addAttribute(TITLE, "Registration Student");
        List<BeanCourseList> lcl = new ArrayList<>();
        BeanStudent l = new BeanStudent();
        List<BeanCourse> lc = servicecourse.getCourses();
        int y = 0;
        for (BeanCourse c : lc) {
            BeanCourseList cl = new BeanCourseList();
            cl.setId(y);
            cl.setCourse(c);
            cl.setFk_course(c.getCourse_code());
            lcl.add(cl);
            y++;
        }
        l.setCourse_list(lcl);
        model.addAttribute("student", l);
        return MODEL_REGISTER_STUDENT;
    }

    @RequestMapping(value = URL_REGISTER_STUDENT, method = RequestMethod.POST)
    public String POSTregisterStudent(Model model, @ModelAttribute("student") BeanStudent s) {
        model.addAttribute(TITLE, "Registration Student");
        boolean f = servicestudent.addStudent(s);
        if (f) {
            f = servicestudentcourse.addStudentCourse(s.getCourse_list(), s.getReg_number());
        }
        if (f) {
            email.sendEmail(s.getEmail(), "Hi " + s.getFirst_name().toUpperCase() + ", Please login with your registration number. Your password is password", "Account registration");
        }
        model.addAttribute(MESSAGE, f ? REG_SUCCESS : REG_FAILED);
        model.addAttribute("student", new BeanStudent());
        return MODEL_REGISTER_STUDENT;
    }

    @RequestMapping(value = URL_CHANGE_PASSWORD, method = RequestMethod.GET)
    public String showChangePassword(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute("title", "Change password    ");
        BeanPasswordChange c = new BeanPasswordChange();
        c.setFk_user(loggedlogin.getFk_user());
        model.addAttribute("pwdchange", c);
        return MODEL_CHANGEPASSWORD;
    }

    @RequestMapping(value = URL_CHANGE_PASSWORD, method = RequestMethod.POST)
    public String POSTshowChangePassword(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute("title", "Lecturers");
        BeanPasswordChange c = new BeanPasswordChange();
        c.setFk_user(loggedlogin.getFk_user());
        model.addAttribute("pwdchange", c);
        return MODEL_CHANGEPASSWORD;
    }

    @RequestMapping(value = {URL_LOGIN}, method = RequestMethod.GET)
    public String showLogin(Model model, HttpServletRequest request) {
        model.addAttribute("message", "");
        model.addAttribute("login", new BeanLogin());
        return MODEL_LOGIN;
    }

    @RequestMapping(value = {URL_LOGIN, URL_LOGOUT}, method = RequestMethod.POST)
    public String postLogin(Model model, @ModelAttribute("login") BeanLogin l,
            HttpServletRequest request) {
        boolean b = servicesettings.authenticate(l);
        if (b) {
            HttpSession session = request.getSession(true);
            session.setAttribute("cloud_id", l.getId());// rs.getString("id"));
            session.setAttribute("cloud_user_id", l.getId());// rs.getString("id"));
            session.setAttribute("cloud_user_name", l.getFullname());// rs.getString("last_name"));
            session.setAttribute("cloud_user_type", l.getFk_user_type());// rs.getString("fk_user_type"));
            session.setAttribute("auth_cloud_user", "1");
            session.setAttribute("username", l.getFullname());
            l.setIpaddress(request.getRemoteAddr());
            return MODEL_HOME;
        } else {
            model.addAttribute("message", "Username or password incorrect");
            model.addAttribute("login", new BeanLogin());
            return MODEL_LOGIN;
        }
    }

    @RequestMapping(value = {URL_SETTINGS}, method = RequestMethod.GET)
    public String showSettings(Model model, HttpServletRequest request, @PathVariable("action") String action) {
        switch (action) {
            case "users":
                model.addAttribute("users", servicesettings.getUsers());
                return MODEL_USERS;
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = {URL_SETTINGS}, method = RequestMethod.POST)
    public String showSettingsPOST(Model model, HttpServletRequest request, @PathVariable("action") String action) {
        switch (action) {
            case "users":
                model.addAttribute("users", servicesettings.getUsers());
                return MODEL_USERS;
            default:
                return MODEL_NOT_FOUND;
        }
    }

    @RequestMapping(value = {URL_LOGOUT}, method = RequestMethod.GET)
    public String logout(Model model, HttpServletRequest request) {
        setSession(model, request);
        HttpSession session = request.getSession(true);
        session.invalidate();
        model.addAttribute("message", "");
        model.addAttribute("login", new BeanLogin());
        return MODEL_LOGIN;
    }

}
