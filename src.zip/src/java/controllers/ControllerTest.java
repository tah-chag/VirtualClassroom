/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import javax.servlet.http.HttpServletRequest;
import model.BeanQuestion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServiceCourse;
import services.ServiceTest;
import utils.LoginSession;

/**
 *
 * @author terence
 */
@Controller
public class ControllerTest extends LoginSession {

    @Autowired
    @Qualifier("ServiceCourse")
    private ServiceCourse servicecource;

    @Autowired
    @Qualifier("ServiceTest")
    private ServiceTest servicetest;

    @RequestMapping(value = URL_TEST, method = RequestMethod.GET)
    public String showTests(Model model, HttpServletRequest request) {
        setSession(model, request);
        model.addAttribute(TITLE, "Test");
        model.addAttribute("q", new BeanQuestion());
        model.addAttribute("courses", servicecource.getCourses());
        model.addAttribute("qs", servicetest.getQuestions());
        return "test/index";
    }

    @RequestMapping(value = URL_TEST, method = RequestMethod.POST)
    public String POSTshowTests(@ModelAttribute("q") BeanQuestion q,
            Model model, HttpServletRequest request) {
        setSession(model, request);
        q.setFk_created_by(loggedlogin.getFk_user());
        boolean f = servicetest.addQuestion(q);
        model.addAttribute(MESSAGE, f ? MESSAGE_SUCCESS : MESSAGE_FAILED);
        model.addAttribute(TITLE, "Test");
        model.addAttribute("q", new BeanQuestion());
        model.addAttribute("courses", servicecource.getCourses());
        model.addAttribute("qs", servicetest.getQuestions());
        return "test/index";
    }

}
