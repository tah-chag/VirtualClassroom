/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import config.DbConn;
import config.ITable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanNotes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DaoNotesImpl implements DaoNotes, ITable {

    @Autowired
    private DbConn conn;
    @Autowired
    private DaoCourse daocourse;
    @Autowired
    private DaoLecturer daolecturer;

    @Override
    public boolean addNotes(BeanNotes n) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_NOTES + " (fk_course,content,fk_created_by) values(?,?,?)");
            ps.setString(1, n.getFk_course());
            ps.setString(2, n.getContent());
            ps.setString(3, n.getFk_created_by());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanNotes getNote(int id) {
        BeanNotes c = new BeanNotes();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_NOTES);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                c.setId(rs.getInt("id"));
                c.setContent(rs.getString("content"));
                c.setFk_course(rs.getString("fk_course"));
                c.setFk_created_by(rs.getString("fk_created_by"));
                c.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                c.setLecturer(daolecturer.getLecturer(rs.getInt("fk_created_by")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return c;
    }

    @Override
    public List<BeanNotes> getNotes() {
        List<BeanNotes> lc = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_NOTES);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanNotes c = new BeanNotes();
                c.setId(rs.getInt("id"));
                c.setContent(rs.getString("content"));
                c.setFk_course(rs.getString("fk_course"));
                c.setFk_created_by(rs.getString("fk_created_by"));
                c.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                c.setLecturer(daolecturer.getLecturer(rs.getString("fk_created_by")));
                lc.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lc;
    }

    @Override
    public List<BeanNotes> getNotes(int id) {
        List<BeanNotes> lc = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_NOTES);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanNotes c = new BeanNotes();
                c.setId(rs.getInt("id"));
                c.setContent(rs.getString("content"));
                c.setFk_course(rs.getString("fk_course"));
                c.setFk_created_by(rs.getString("fk_created_by"));
                c.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                c.setLecturer(daolecturer.getLecturer(rs.getInt("fk_created_by")));
                lc.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lc;
    }

    @Override
    public List<BeanNotes> getNotesByLecturer(int id) {
        List<BeanNotes> lc = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_NOTES);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanNotes c = new BeanNotes();
                c.setId(rs.getInt("id"));
                c.setContent(rs.getString("content"));
                c.setFk_course(rs.getString("fk_course"));
                c.setFk_created_by(rs.getString("fk_created_by"));
                c.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                c.setLecturer(daolecturer.getLecturer(rs.getInt("fk_created_by")));
                lc.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lc;
    }

    @Override
    public BeanNotes getNote(BeanNotes n) {
        BeanNotes c = new BeanNotes();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_NOTES);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                c.setId(rs.getInt("id"));
                c.setContent(rs.getString("content"));
                c.setFk_course(rs.getString("fk_course"));
                c.setFk_created_by(rs.getString("fk_created_by"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return c;
    }

}
