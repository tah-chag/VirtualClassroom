/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.BeanStudent;

/**
 *
 * @author tariro
 */
public interface DaoStudent {

    boolean addStudent(BeanStudent s);

    boolean updateStudent(BeanStudent s);

    BeanStudent getStudent(String r);

    List<BeanStudent> getStudents();
}
