/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoAssignment;
import dao.DaoCourse;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanAssignment;
import model.BeanAssignmentStudent;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import utils.UFormatter;

@Repository
@Transactional
public class DaoAssignmentImpl implements DaoAssignment, ITable {
    
    @Autowired
    private DbConn conn;
    @Autowired
    private UFormatter u;
    @Autowired
    DaoCourse daocourse;
    
    @Override
    public boolean addAssignment(BeanAssignment a) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_ASSIGNMENT + " (fk_course,due_date,fk_created_by) VALUES(?,?,?)");
            ps.setString(1, a.getFk_course());
            ps.setString(2, u.dateR(a.getDue_date()));
            ps.setString(3, a.getFk_created_by());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }
    
    @Override
    public List<BeanAssignment> getAssignments() {
        List<BeanAssignment> la = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_ASSIGNMENT);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanAssignment a = new BeanAssignment();
                a.setDue_date(rs.getString("due_date"));
                a.setId(rs.getInt("id"));
                a.setFk_created_by(rs.getString("fk_created_by"));
                a.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                la.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return la;
    }
    
    @Override
    public BeanAssignment getAssignment(int id) {
        BeanAssignment a = new BeanAssignment();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_ASSIGNMENT + " WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                a.setCourse(daocourse.getCourse(rs.getString("fk_course")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return a;
    }
    
    @Override
    public BeanAssignment getAssignment(BeanAssignment a) {
        BeanAssignment c = new BeanAssignment();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_ASSIGNMENT + " WHERE fk_course=? AND fk_created_by=? AND due_date=?");
            ps.setString(1, a.getFk_course());
            ps.setString(2, a.getFk_created_by());
            ps.setString(3, u.dateR(a.getDue_date()));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                c.setId(rs.getInt("id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return c;
    }
    
    @Override
    public boolean addStudentAssignment(BeanAssignmentStudent a) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_ASSIGNMENT_STUDENT + " (fk_assignment,fk_student,date_submitted,comment) VALUES(?,?,now(),?)");
            ps.setInt(1, a.getFk_assignment());
            ps.setString(2, a.getFk_student());
            ps.setString(3, a.getComment());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }
    
    @Override
    public List<BeanAssignmentStudent> getStudentAssignments() {
        List<BeanAssignmentStudent> la = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT s.*,if(date_submitted<due_date,0,1) as l FROM " + TBL_ASSIGNMENT_STUDENT + " as s LEFT JOIN " + TBL_ASSIGNMENT + " as a ON a.id=fk_assignment");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanAssignmentStudent r = new BeanAssignmentStudent();
                r.setId(rs.getInt("id"));
                r.setFk_assignment(rs.getInt("fk_assignment"));
                r.setFk_student(rs.getString("fk_student"));
                r.setDate_created(rs.getString("date_submitted"));
                r.setAssignment(getAssignment(r.getFk_assignment()));
                r.setLate(rs.getBoolean("l"));
                la.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        System.err.println("SAssingments " + la.size());
        return la;
    }
    
    @Override
    public BeanAssignmentStudent getStudentAssignment(BeanAssignmentStudent a) {
        BeanAssignmentStudent r = new BeanAssignmentStudent();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT s.*,if(date_submitted<due_date,0,1) as l FROM " + TBL_ASSIGNMENT_STUDENT + " as s LEFT JOIN " + TBL_ASSIGNMENT + " as a ON a.id=fk_assignment" + " WHERE s.fk_assignment=? AND s.fk_student=?");
            ps.setInt(1, a.getFk_assignment());
            ps.setString(2, a.getFk_student());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                r.setId(rs.getInt("id"));
                r.setFk_student(rs.getString("fk_student"));
                r.setDate_created(rs.getString("date_submitted"));
                r.setLate(rs.getBoolean("l"));
                r.setComment(rs.getString("comment"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return r;
    }
    
    @Override
    public List<BeanAssignmentStudent> getStudentAssignments(String student) {
        List<BeanAssignmentStudent> la = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT s.*,if(date_submitted<due_date,0,1) as l FROM " + TBL_ASSIGNMENT_STUDENT + " as s LEFT JOIN " + TBL_ASSIGNMENT + " as a ON a.id=fk_assignment" + " WHERE fk_student=?");
            ps.setString(1, student);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanAssignmentStudent r = new BeanAssignmentStudent();
                r.setId(rs.getInt("id"));
                r.setFk_assignment(rs.getInt("fk_assignment"));
                r.setFk_student(rs.getString("fk_student"));
                r.setDate_created(rs.getString("date_submitted"));
                r.setAssignment(getAssignment(r.getFk_assignment()));
                r.setLate(rs.getBoolean("l"));
             r.setComment(rs.getString("comment"));   la.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        System.err.println("SAssingments " + la.size());
        return la;
    }
    
    @Override
    public List<BeanAssignment> getAssignments(BeanLogin l) {
        List<BeanAssignment> la = new ArrayList<>();
        try {
            PreparedStatement ps;
            switch (l.getFk_user_type()) {
                case 2://student
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_ASSIGNMENT + "  WHERE fk_course IN (select fk_course FROM " + TBL_STUDENT_COURSE + " WHERE fk_student=?)");
                    ps.setString(1, l.getFk_user());
                    break;
                case 3://lecturer
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_ASSIGNMENT + " WHERE fk_course IN (select fk_course FROM " + TBL_LECTURER_COURSE + " WHERE fk_lecturer=?)");
                    ps.setString(1, l.getFk_user());
                    break; //case 1://root
                default:
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_ASSIGNMENT);
                    break;
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanAssignment a = new BeanAssignment();
                a.setDue_date(rs.getString("due_date"));
                a.setId(rs.getInt("id"));
                a.setFk_created_by(rs.getString("fk_created_by"));
                a.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                la.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return la;
    }
    
    @Override
    public List<BeanAssignmentStudent> getStudentAssignments(BeanLogin l) {
        List<BeanAssignmentStudent> la = new ArrayList<>();
        try {
            PreparedStatement ps;
            switch (l.getFk_user_type()) {
                case 2://student
                    ps = conn.getCon().prepareStatement("SELECT s.*,if(date_submitted<due_date,0,1) as l FROM " + TBL_ASSIGNMENT_STUDENT + " as s LEFT JOIN " + TBL_ASSIGNMENT + " as a ON a.id=fk_assignment WHERE fk_course IN (select fk_course FROM " + TBL_STUDENT_COURSE + " WHERE fk_student=?)");
                    ps.setString(1, l.getFk_user());
                    break;
                case 3://lecturer
                    ps = conn.getCon().prepareStatement("SELECT s.*,if(date_submitted<due_date,0,1) as l FROM " + TBL_ASSIGNMENT_STUDENT + " as s LEFT JOIN " + TBL_ASSIGNMENT + " as a ON a.id=fk_assignment WHERE fk_course IN (select fk_course FROM " + TBL_LECTURER_COURSE + " WHERE fk_lecturer=?)");
                    ps.setString(1, l.getFk_user());
                    break; //case 1://root
                default:
                    ps = conn.getCon().prepareStatement("SELECT s.*,if(date_submitted<due_date,0,1) as l FROM " + TBL_ASSIGNMENT_STUDENT + " as s LEFT JOIN " + TBL_ASSIGNMENT + " as a ON a.id=fk_assignment");
                    break;
                
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanAssignmentStudent r = new BeanAssignmentStudent();
                r.setId(rs.getInt("id"));
                r.setFk_assignment(rs.getInt("fk_assignment"));
                r.setFk_student(rs.getString("fk_student"));
                r.setDate_created(rs.getString("date_submitted"));
                r.setAssignment(getAssignment(r.getFk_assignment()));
                r.setLate(rs.getBoolean("l"));
               r.setComment(rs.getString("comment")); la.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        System.err.println("SAssingments " + la.size());
        return la;
    }
}
