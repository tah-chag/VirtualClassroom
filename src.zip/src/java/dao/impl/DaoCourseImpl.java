/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoCourse;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanCourse;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DaoCourseImpl implements DaoCourse, ITable {

    @Autowired
    private DbConn conn;

    @Override
    public boolean addCourse(BeanCourse c) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_COURSE
                    + " (course_code,course_name) VALUES(?,?)");
            ps.setString(1, c.getCourse_code());
            ps.setString(2, c.getCourse_name());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanCourse getCourse(String r) {
        BeanCourse c = new BeanCourse();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_COURSE + " WHERE course_code=?");
            ps.setString(1, r);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                c.setCourse_code(rs.getString("course_code"));
                c.setCourse_name(rs.getString("course_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return c;
    }

    @Override
    public List<BeanCourse> getCourses() {
        List<BeanCourse> lc = new ArrayList<BeanCourse>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_COURSE + " ORDER BY course_name");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanCourse c = new BeanCourse();
                c.setCourse_code(rs.getString("course_code"));
                c.setCourse_name(rs.getString("course_name"));
                lc.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lc;
    }

    @Override
    public List<BeanCourse> getCourses(String p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<BeanCourse> getCourses(BeanLogin l) {
        List<BeanCourse> lc = new ArrayList<BeanCourse>();
        try {
            PreparedStatement ps;
            switch (l.getFk_user_type()) {
                case 2://student
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_COURSE + " WHERE course_code IN (select fk_course FROM " + TBL_STUDENT_COURSE + " WHERE fk_student=?) ORDER BY course_name");
                    ps.setString(1, l.getFk_user());
                    break;
                case 3://lecturer
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_COURSE + " WHERE course_code IN (select fk_course FROM " + TBL_LECTURER_COURSE + " WHERE fk_lecturer=?) ORDER BY course_name");
                    ps.setString(1, l.getFk_user());
                    break; //case 1://root
                default:
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_COURSE + " ORDER BY course_name");
                    break;

            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanCourse c = new BeanCourse();
                c.setCourse_code(rs.getString("course_code"));
                c.setCourse_name(rs.getString("course_name"));
                lc.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lc;
    }

    @Override
    public boolean updateCourse(BeanCourse c) {
        try {
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public boolean delete(String c) {
        try {
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public int getCount() {
        int x = 0;
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT COUNT(*) FROM " + TBL_COURSE);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                x = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
         return x;
    }

}
