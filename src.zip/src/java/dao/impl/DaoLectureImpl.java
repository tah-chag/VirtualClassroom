/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoCourse;
import dao.DaoLecture;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanLecture;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import utils.UFormatter;

@Repository
@Transactional
public class DaoLectureImpl implements DaoLecture, ITable {

    @Autowired
    private DbConn conn;
    @Autowired
    private DaoCourse daocourse;
    @Autowired
    private UFormatter u;

    @Override
    public boolean addLecture(BeanLecture l) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_LECTURE + "(fk_course,lecture_name,start_date,fk_created_by,ip) VALUES(?,?,?,?,?)");
            ps.setString(1, l.getFk_course());
            ps.setString(2, l.getLecture_name());
            ps.setString(3, u.dateR(l.getStart_date()));
            ps.setInt(4, l.getFk_created_by());
            ps.setString(5, l.getIp());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanLecture getLecture(int id) {
        BeanLecture l = new BeanLecture();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURE + " WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                l.setId(rs.getInt("id"));
                l.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                l.setStart_date(rs.getString("start_Date"));
                l.setLecture_name(rs.getString("lecture_name"));
                l.setIp(rs.getString("ip"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return l;
    }

    @Override
    public List<BeanLecture> getLectures(String c) {
        List<BeanLecture> ll = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURE);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanLecture l = new BeanLecture();
                l.setId(rs.getInt("id"));
                l.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                l.setStart_date(rs.getString("start_Date"));
                l.setLecture_name(rs.getString("lecture_name"));
                l.setIp(rs.getString("ip"));
                ll.add(l);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ll;
    }

    @Override
    public List<BeanLecture> getLectures() {
        List<BeanLecture> ll = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURE);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanLecture l = new BeanLecture();
                l.setId(rs.getInt("id"));
                l.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                l.setStart_date(rs.getString("start_Date"));
                l.setLecture_name(rs.getString("lecture_name"));
                l.setIp(rs.getString("ip"));
                ll.add(l);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ll;
    }

    @Override
    public List<BeanLecture> getLectures(BeanLogin k) {
       List<BeanLecture> ll = new ArrayList<>();
        try {
            PreparedStatement ps;
            switch (k.getFk_user_type()) {
                case 2://student
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURE + " WHERE fk_course IN (select fk_course FROM " + TBL_STUDENT_COURSE + " WHERE fk_student=?) ORDER BY start_date");
                    ps.setString(1, k.getFk_user());
                    break;
                case 3://lecturer
                    ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURE + " WHERE fk_course IN (select fk_course FROM " + TBL_LECTURER_COURSE + " WHERE fk_lecturer=?) ORDER BY start_date");
                    ps.setString(1, k.getFk_user());
                    break; //case 1://root
                default:
                     ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURE+" ");
                    break;

            }
           
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanLecture l = new BeanLecture();
                l.setId(rs.getInt("id"));
                l.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                l.setStart_date(rs.getString("start_Date"));
                l.setLecture_name(rs.getString("lecture_name"));
                l.setIp(rs.getString("ip"));
                ll.add(l);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ll;
    }
}
