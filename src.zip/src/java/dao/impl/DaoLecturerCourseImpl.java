/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoLecturerCourse;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import model.BeanCourseList;
import model.BeanLecturerCourse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DaoLecturerCourseImpl implements DaoLecturerCourse, ITable {

    @Autowired
    private DbConn conn;

    @Override
    public boolean addLectureCourse(List<BeanCourseList> lc, String s) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_LECTURER_COURSE + " (fk_course,fk_lecturer) VALUES(?,?)");
            for (BeanCourseList c : lc) {
                if (c.isRegister()) {
                    ps.setString(1, c.getFk_course());
                    ps.setString(2, s);
                    ps.addBatch();
                }
            }
            ps.executeBatch();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public List<BeanLecturerCourse> getLecturerCourse(String id) {
        List<BeanLecturerCourse> lc = new ArrayList<>();
        try {
        } catch (Exception e) {
        } finally {
            conn.closeConn();
        }
        return lc;
    }
}
