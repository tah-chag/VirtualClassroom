/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoLecturer;
import dao.DaoUser;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanLecturer;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import utils.UFormatter;

@Repository
@Transactional
public class DaoLecturerImpl implements DaoLecturer, ITable {

    @Autowired
    private DbConn conn;
    @Autowired
    private UFormatter u;
    @Autowired
    private DaoUser daouser;

    @Override
    public boolean addLecturer(BeanLecturer l) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_LECTURER
                    + "(ec_number,fk_title,last_name,first_name,other_names,gender,dob,email) VALUES(?,?,?,?,?,?,?,?)");
            ps.setString(1, l.getEc_number());
            ps.setInt(2, l.getFk_title());
            ps.setString(3, l.getLast_name());
            ps.setString(4, l.getFirst_name());
            ps.setString(5, l.getOther_names());
            ps.setString(6, l.getGender());
            ps.setString(7, u.dateR(l.getDob()));
            ps.setString(8, l.getEmail());
            ps.executeUpdate();
            BeanLogin ll = new BeanLogin();
            ll.setFk_user_type(3);
            ll.setUsername(l.getEc_number());
            ll.setFk_user(l.getEc_number());
            daouser.addLogin(ll);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public boolean updateLEcturer(BeanLecturer l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BeanLecturer getLecturer(int id) {
        BeanLecturer l = new BeanLecturer();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURER + " WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                l.setEc_number(rs.getString("ec_number"));
                l.setLast_name(rs.getString("last_name"));
                l.setFirst_name(rs.getString("first_name"));
                l.setGender(rs.getString("gender"));
                l.setOther_names(rs.getString("other_names"));
                l.setEmail(rs.getString("email"));
                l.setDob(rs.getString("dob"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return l;
    }

    @Override
    public List<BeanLecturer> getLecturers() {
        List<BeanLecturer> ll = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURER);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanLecturer l = new BeanLecturer();
                l.setEc_number(rs.getString("ec_number"));
                l.setLast_name(rs.getString("last_name"));
                l.setFirst_name(rs.getString("first_name"));
                l.setGender(rs.getString("gender"));
                l.setOther_names(rs.getString("other_names"));
                l.setEmail(rs.getString("email"));
                l.setDob(rs.getString("dob"));
                ll.add(l);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return ll;
    }

    @Override
    public BeanLecturer getLecturer(String id) {
        BeanLecturer l = new BeanLecturer();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LECTURER + " WHERE ec_number=?");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                l.setEc_number(rs.getString("ec_number"));
                l.setLast_name(rs.getString("last_name"));
                l.setFirst_name(rs.getString("first_name"));
                l.setGender(rs.getString("gender"));
                l.setOther_names(rs.getString("other_names"));
                l.setEmail(rs.getString("email"));
                l.setDob(rs.getString("dob"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return l;
    }

}
