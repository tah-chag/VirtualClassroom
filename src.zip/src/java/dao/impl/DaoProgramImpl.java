/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoProgram;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanProgram;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DaoProgramImpl implements DaoProgram, ITable {

    @Autowired
    private DbConn conn;

    @Override
    public boolean addProgram(BeanProgram p) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_PROGR + "(program_code,program_name) VALUES(?,?)");
            ps.setString(1, p.getProgram_code());
            ps.setString(2, p.getProgram_name());
            ps.setString(2, p.getProgram_name());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanProgram getProgram(String c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<BeanProgram> getPrograms() {
        List<BeanProgram> lc = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_PROGR);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanProgram p = new BeanProgram();
                p.setProgram_code(rs.getString("program_code"));
                p.setProgram_name(rs.getString("program_name"));
                lc.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lc;
    }

    @Override
    public boolean updateProgram(BeanProgram p) {
        try {
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public boolean delete(String c) {
        try {
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }
}
