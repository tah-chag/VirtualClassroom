/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoStudentCourse;
import java.sql.PreparedStatement;
import java.util.List;
import model.BeanCourseList;
import model.BeanStudentCourse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DaoStudentCourseImpl implements DaoStudentCourse, ITable {

    @Autowired
    private DbConn conn;

    @Override
    public boolean addStudentCourse(List<BeanCourseList> lc, String s) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_STUDENT_COURSE + " (fk_course,fk_student) VALUES(?,?)");
            for (BeanCourseList c : lc) {
                if (c.isRegister()) {
                    ps.setString(1, c.getFk_course());
                    ps.setString(2, s);
                    ps.addBatch();
                }
            }
            ps.executeBatch();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public List<BeanStudentCourse> getStudentCourses(String r) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
