/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoStudent;
import dao.DaoUser;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanLogin;
import model.BeanStudent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import utils.UFormatter;

@Repository
@Transactional
public class DaoStudentImpl implements DaoStudent, ITable {

    @Autowired
    private DbConn conn;

    @Autowired
    private UFormatter u;

    @Autowired
    private DaoUser daouser;

    @Override
    public boolean addStudent(BeanStudent s) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_STUDENT + "(reg_number,last_name,first_name,other_names,gender,dob,email) values(?,?,?,?,?,?,?) ");
            ps.setString(1, s.getReg_number());
            ps.setString(2, s.getLast_name());
            ps.setString(3, s.getFirst_name());
            ps.setString(4, s.getOther_names());
            ps.setString(5, s.getGender());
            ps.setString(6, u.dateR(s.getDob()));
            ps.setString(7, s.getEmail());
            ps.executeUpdate();
            BeanLogin l = new BeanLogin();
            l.setFk_user_type(2);
            l.setUsername(s.getReg_number());
            l.setFk_user(s.getReg_number());
            daouser.addLogin(l);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public boolean updateStudent(BeanStudent s) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BeanStudent getStudent(String r) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<BeanStudent> getStudents() {
        List<BeanStudent> ls = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_STUDENT);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanStudent s = new BeanStudent();
                s.setReg_number(rs.getString("reg_number"));
                s.setFirst_name(rs.getString("first_name"));
                s.setLast_name(rs.getString("last_name"));
                s.setOther_names(rs.getString("other_names"));
                s.setDob(rs.getString("dob"));
                s.setGender(rs.getString("gender"));
                ls.add(s);
            }
        } catch (Exception e) {
        } finally {
        }
        return ls;
    }

}
