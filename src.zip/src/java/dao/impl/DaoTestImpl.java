/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoCourse;
import dao.DaoTest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanQuestion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DaoTestImpl implements DaoTest, ITable {

    @Autowired
    private DbConn conn;
    @Autowired
    private DaoCourse daocourse;

    @Override
    public boolean addQuestion(BeanQuestion q) {
        try {
            if (q.getQuestion().trim().length() > 3) {
                PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_QUESTION + " (fk_course,description,fk_created_by) VALUES(?,?,?)");
                ps.setString(1, q.getFk_course());
                ps.setString(2, q.getQuestion());
                ps.setString(3, q.getFk_created_by());
                ps.executeUpdate();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanQuestion getQuestion(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<BeanQuestion> getQuestions(String course, int q) {
        List<BeanQuestion> lq = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_QUESTION);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanQuestion qq = new BeanQuestion();
                qq.setId(rs.getInt("id"));
                qq.setFk_course(rs.getString("fk_course"));
                qq.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                qq.setQuestion(rs.getString("question"));
                lq.add(qq);
            }
        } catch (Exception e) {
        } finally {
        }
        return lq;
    }

    @Override
    public List<BeanQuestion> getQuestions() {
        List<BeanQuestion> lq = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_QUESTION);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanQuestion qq = new BeanQuestion();
                qq.setId(rs.getInt("id"));
                qq.setFk_course(rs.getString("fk_course"));
                qq.setCourse(daocourse.getCourse(rs.getString("fk_course")));
                qq.setFk_created_by(rs.getString("fk_created_by"));
                qq.setQuestion(rs.getString("description"));
                lq.add(qq);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return lq;
    }

}
