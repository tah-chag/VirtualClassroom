/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.impl;

import config.DbConn;
import config.ITable;
import dao.DaoUser;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.BeanLogin;
import model.BeanUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.codec.digest.DigestUtils;
import utils.UFormatter;

@Transactional(readOnly = true)
@Repository
public class DaoUserImpl implements DaoUser, ITable {

    @Autowired
    private DbConn conn;
    @Autowired
    private UFormatter u;

    @Override
    public boolean authenticate(BeanLogin l) {
        l.setPassword(DigestUtils.md5Hex(l.getPassword()));
        //    System.err.println(l.getPassword());
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LOGIN + " WHERE email=? and password=?");
            ps.setString(1, l.getUsername());
            ps.setString(2, l.getPassword());
            ResultSet rs = ps.executeQuery();//System.err.println(rs.);
            if (rs.next()) {
                //System.err.println("Fullname " + rs.getString("fullname"));
                l.setId(rs.getInt("id"));
                l.setFk_user(rs.getString("fk_user"));
                l.setFk_user_type(rs.getInt("fk_user_type"));
                l.setUsername(rs.getString("email"));
                // l.setFullname(rs.getString("last_name") + " " + rs.getString("first_name"));
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public boolean addUser(BeanUser a) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_USER + " (fk_user_type,email,password,natid,last_name,first_name,other_names,gender,dob) values(?,?,?,?,?,?,?,?,?)");
            ps.setString(3, DigestUtils.md5Hex("password"));
            ps.setString(8, a.getGender());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public boolean updateUser(BeanUser u) {
        try {
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanUser getUserById(int id) {
        BeanUser u = new BeanUser();
        return u;
    }

    @Override
    public List<BeanUser> getUsers() {
        UFormatter uf = new UFormatter();
        List<BeanUser> lu = new ArrayList<>();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_USER + " WHERE fk_user_type<>1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BeanUser u = new BeanUser();
                u.setGender(rs.getString("gender"));
                lu.add(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return lu;
    }

    @Override
    public boolean addLogin(BeanLogin l) {
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("INSERT INTO " + TBL_LOGIN + " (fk_user_type,fk_user,email,password) values(?,?,?,md5(?))");
            ps.setInt(1, l.getFk_user_type());
            ps.setString(2, l.getFk_user());
            ps.setString(3, l.getUsername());
            ps.setString(4, "password");
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conn.closeConn();
        }
    }

    @Override
    public BeanLogin getLogin(int id) {
        BeanLogin l = new BeanLogin();
        try {
            PreparedStatement ps = conn.getCon().prepareStatement("SELECT * FROM " + TBL_LOGIN + " WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();//System.err.println(rs.);
            if (rs.next()) {
                //System.err.println("Fullname " + rs.getString("fullname"));
                l.setId(rs.getInt("id"));
                l.setFk_user(rs.getString("fk_user"));
                l.setFk_user_type(rs.getInt("fk_user_type"));
                l.setUsername(rs.getString("email"));
                // l.setFullname(rs.getString("last_name") + " " + rs.getString("first_name"));
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.closeConn();
        }
        return l;
    }

}
