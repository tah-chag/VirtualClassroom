/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author tariro
 */
public class BeanAssignment {

    private int id;
    private String fk_course, fk_created_by, due_date, date_created;
    private BeanCourse course;
    private BeanLecturer lecturer;
    private MultipartFile file;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the fk_course
     */
    public String getFk_course() {
        return fk_course;
    }

    /**
     * @param fk_course the fk_course to set
     */
    public void setFk_course(String fk_course) {
        this.fk_course = fk_course;
    }

    /**
     * @return the fk_created_by
     */
    public String getFk_created_by() {
        return fk_created_by;
    }

    /**
     * @param fk_created_by the fk_created_by to set
     */
    public void setFk_created_by(String fk_created_by) {
        this.fk_created_by = fk_created_by;
    }

    /**
     * @return the due_date
     */
    public String getDue_date() {
        return due_date;
    }

    /**
     * @param due_date the due_date to set
     */
    public void setDue_date(String due_date) {
        this.due_date = due_date;
    }

    /**
     * @return the date_created
     */
    public String getDate_created() {
        return date_created;
    }

    /**
     * @param date_created the date_created to set
     */
    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    /**
     * @return the course
     */
    public BeanCourse getCourse() {
        return course;
    }

    /**
     * @param course the course to set
     */
    public void setCourse(BeanCourse course) {
        this.course = course;
    }

    /**
     * @return the lecturer
     */
    public BeanLecturer getLecturer() {
        return lecturer;
    }

    /**
     * @param lecturer the lecturer to set
     */
    public void setLecturer(BeanLecturer lecturer) {
        this.lecturer = lecturer;
    }

    /**
     * @return the file
     */
    public MultipartFile getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(MultipartFile file) {
        this.file = file;
    }

}
