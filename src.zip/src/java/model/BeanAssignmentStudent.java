/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author terence
 */
public class BeanAssignmentStudent {

    private int id, fk_assignment;
    private String comment, fk_student, date_created;
    private MultipartFile file;
    private BeanAssignment assignment;
    private boolean late;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the fk_student
     */
    public String getFk_student() {
        return fk_student;
    }

    /**
     * @param fk_student the fk_student to set
     */
    public void setFk_student(String fk_student) {
        this.fk_student = fk_student;
    }

    /**
     * @return the date_created
     */
    public String getDate_created() {
        return date_created;
    }

    /**
     * @param date_created the date_created to set
     */
    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    /**
     * @return the fk_assignment
     */
    public int getFk_assignment() {
        return fk_assignment;
    }

    /**
     * @param fk_assignment the fk_assignment to set
     */
    public void setFk_assignment(int fk_assignment) {
        this.fk_assignment = fk_assignment;
    }

    /**
     * @return the file
     */
    public MultipartFile getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(MultipartFile file) {
        this.file = file;
    }

    /**
     * @return the assignment
     */
    public BeanAssignment getAssignment() {
        return assignment;
    }

    /**
     * @param assignment the assignment to set
     */
    public void setAssignment(BeanAssignment assignment) {
        this.assignment = assignment;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the late
     */
    public boolean isLate() {
        return late;
    }

    /**
     * @param late the late to set
     */
    public void setLate(boolean late) {
        this.late = late;
    }
}
