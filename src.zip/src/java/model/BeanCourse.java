/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tariro
 */
public class BeanCourse {

    private int id;
    private String course_code, course_name;

    /**
     * @return the course_code
     */
    public String getCourse_code() {
        return course_code;
    }

    /**
     * @param course_code the course_code to set
     */
    public void setCourse_code(String course_code) {
        this.course_code = course_code;
    }

    /**
     * @return the course_name
     */
    public String getCourse_name() {
        return course_name;
    }

    /**
     * @param course_name the course_name to set
     */
    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
