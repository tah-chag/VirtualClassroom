/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author terence
 */
public class BeanCourseList {

    private int id;
    private String fk_course;
    private boolean register;
    private BeanCourse course;

    /**
     * @return the fk_course
     */
    public String getFk_course() {
        return fk_course;
    }

    /**
     * @param fk_course the fk_course to set
     */
    public void setFk_course(String fk_course) {
        this.fk_course = fk_course;
    }

    /**
     * @return the register
     */
    public boolean isRegister() {
        return register;
    }

    /**
     * @param register the register to set
     */
    public void setRegister(boolean register) {
        this.register = register;
    }

    /**
     * @return the course
     */
    public BeanCourse getCourse() {
        return course;
    }

    /**
     * @param course the course to set
     */
    public void setCourse(BeanCourse course) {
        this.course = course;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
