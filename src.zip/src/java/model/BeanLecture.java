/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author tariro
 */
public class BeanLecture {

    private int id, fk_created_by;
    private String fk_course, file_path, ip, lecture_name, start_date, start_time;
    private MultipartFile file;
    private BeanCourse course;
    private BeanLecturer lecturer;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the fk_created_by
     */
    public int getFk_created_by() {
        return fk_created_by;
    }

    /**
     * @param fk_created_by the fk_created_by to set
     */
    public void setFk_created_by(int fk_created_by) {
        this.fk_created_by = fk_created_by;
    }

    /**
     * @return the fk_course
     */
    public String getFk_course() {
        return fk_course;
    }

    /**
     * @param fk_course the fk_course to set
     */
    public void setFk_course(String fk_course) {
        this.fk_course = fk_course;
    }

    /**
     * @return the file_path
     */
    public String getFile_path() {
        return file_path;
    }

    /**
     * @param file_path the file_path to set
     */
    public void setFile_path(String file_path) {
        this.file_path = file_path;
    }

    /**
     * @return the lecture_name
     */
    public String getLecture_name() {
        return lecture_name;
    }

    /**
     * @param lecture_name the lecture_name to set
     */
    public void setLecture_name(String lecture_name) {
        this.lecture_name = lecture_name;
    }

    /**
     * @return the start_date
     */
    public String getStart_date() {
        return start_date;
    }

    /**
     * @param start_date the start_date to set
     */
    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    /**
     * @return the start_time
     */
    public String getStart_time() {
        return start_time;
    }

    /**
     * @param start_time the start_time to set
     */
    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    /**
     * @return the file
     */
    public MultipartFile getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(MultipartFile file) {
        this.file = file;
    }

    /**
     * @return the course
     */
    public BeanCourse getCourse() {
        return course;
    }

    /**
     * @param course the course to set
     */
    public void setCourse(BeanCourse course) {
        this.course = course;
    }

    /**
     * @return the lecturer
     */
    public BeanLecturer getLecturer() {
        return lecturer;
    }

    /**
     * @param lecturer the lecturer to set
     */
    public void setLecturer(BeanLecturer lecturer) {
        this.lecturer = lecturer;
    }

    /**
     * @return the ip
     */
    public String getIp() {
        return ip;
    }

    /**
     * @param ip the ip to set
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

}
