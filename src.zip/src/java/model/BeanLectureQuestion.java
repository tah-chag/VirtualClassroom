/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author terence
 */
public class BeanLectureQuestion {

    private int id, fk_lecture, fk_question;
    private String fk_student, question;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the fk_lecture
     */
    public int getFk_lecture() {
        return fk_lecture;
    }

    /**
     * @param fk_lecture the fk_lecture to set
     */
    public void setFk_lecture(int fk_lecture) {
        this.fk_lecture = fk_lecture;
    }

    /**
     * @return the fk_student
     */
    public String getFk_student() {
        return fk_student;
    }

    /**
     * @param fk_student the fk_student to set
     */
    public void setFk_student(String fk_student) {
        this.fk_student = fk_student;
    }

    /**
     * @return the question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * @param question the question to set
     */
    public void setQuestion(String question) {
        this.question = question;
    }

    /**
     * @return the fk_question
     */
    public int getFk_question() {
        return fk_question;
    }

    /**
     * @param fk_question the fk_question to set
     */
    public void setFk_question(int fk_question) {
        this.fk_question = fk_question;
    }
}
