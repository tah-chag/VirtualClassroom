/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author terence
 */
public class BeanLecturerCourse {

    private String fk_course, fk_lecturer;

    /**
     * @return the fk_course
     */
    public String getFk_course() {
        return fk_course;
    }

    /**
     * @param fk_course the fk_course to set
     */
    public void setFk_course(String fk_course) {
        this.fk_course = fk_course;
    }

    /**
     * @return the fk_lecturer
     */
    public String getFk_lecturer() {
        return fk_lecturer;
    }

    /**
     * @param fk_lecturer the fk_lecturer to set
     */
    public void setFk_lecturer(String fk_lecturer) {
        this.fk_lecturer = fk_lecturer;
    }
}
