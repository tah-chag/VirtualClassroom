/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tariro
 */
public class BeanLogin {

    private int id, fk_user_type;
    private String fk_user, password, username, ipaddress, fullname;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the fk_user_type
     */
    public int getFk_user_type() {
        return fk_user_type;
    }

    /**
     * @param fk_user_type the fk_user_type to set
     */
    public void setFk_user_type(int fk_user_type) {
        this.fk_user_type = fk_user_type;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the ipaddress
     */
    public String getIpaddress() {
        return ipaddress;
    }

    /**
     * @param ipaddress the ipaddress to set
     */
    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    /**
     * @return the fullname
     */
    public String getFullname() {
        return fullname;
    }

    /**
     * @param fullname the fullname to set
     */
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    /**
     * @return the fk_user
     */
    public String getFk_user() {
        return fk_user;
    }

    /**
     * @param fk_user the fk_user to set
     */
    public void setFk_user(String fk_user) {
        this.fk_user = fk_user;
    }

}
