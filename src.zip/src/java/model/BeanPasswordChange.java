/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tariro
 */
public class BeanPasswordChange {

    private int fk_user_type;
    private String fk_user, password, confirm_password;

    /**
     * @return the fk_user_type
     */
    public int getFk_user_type() {
        return fk_user_type;
    }

    /**
     * @param fk_user_type the fk_user_type to set
     */
    public void setFk_user_type(int fk_user_type) {
        this.fk_user_type = fk_user_type;
    }

    /**
     * @return the fk_user
     */
    public String getFk_user() {
        return fk_user;
    }

    /**
     * @param fk_user the fk_user to set
     */
    public void setFk_user(String fk_user) {
        this.fk_user = fk_user;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the confirm_password
     */
    public String getConfirm_password() {
        return confirm_password;
    }

    /**
     * @param confirm_password the confirm_password to set
     */
    public void setConfirm_password(String confirm_password) {
        this.confirm_password = confirm_password;
    }
}
