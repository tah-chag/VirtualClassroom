/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tariro
 */
public class BeanProgram {

    private String program_code, program_name;

    /**
     * @return the program_code
     */
    public String getProgram_code() {
        return program_code;
    }

    /**
     * @param program_code the program_code to set
     */
    public void setProgram_code(String program_code) {
        this.program_code = program_code;
    }

    /**
     * @return the program_name
     */
    public String getProgram_name() {
        return program_name;
    }

    /**
     * @param program_name the program_name to set
     */
    public void setProgram_name(String program_name) {
        this.program_name = program_name;
    }
}
