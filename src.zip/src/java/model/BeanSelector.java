/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tariro
 */
public class BeanSelector {

    private String fk_course;

    /**
     * @return the fk_course
     */
    public String getFk_course() {
        return fk_course;
    }

    /**
     * @param fk_course the fk_course to set
     */
    public void setFk_course(String fk_course) {
        this.fk_course = fk_course;
    }
}
