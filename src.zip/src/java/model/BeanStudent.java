/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;

/**
 *
 * @author tariro
 */
public class BeanStudent {

    private String dob, reg_number, email, last_name, first_name, other_names, gender, date_created;
    private List<BeanCourseList> course_list;

    /**
     * @return the reg_number
     */
    public String getReg_number() {
        return reg_number;
    }

    /**
     * @param reg_number the reg_number to set
     */
    public void setReg_number(String reg_number) {
        this.reg_number = reg_number;
    }

    /**
     * @return the last_name
     */
    public String getLast_name() {
        return last_name;
    }

    /**
     * @param last_name the last_name to set
     */
    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    /**
     * @return the first_name
     */
    public String getFirst_name() {
        return first_name;
    }

    /**
     * @param first_name the first_name to set
     */
    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    /**
     * @return the other_names
     */
    public String getOther_names() {
        return other_names;
    }

    /**
     * @param other_names the other_names to set
     */
    public void setOther_names(String other_names) {
        this.other_names = other_names;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the date_created
     */
    public String getDate_created() {
        return date_created;
    }

    /**
     * @param date_created the date_created to set
     */
    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    /**
     * @return the dob
     */
    public String getDob() {
        return dob;
    }

    /**
     * @param dob the dob to set
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * @return the course_list
     */
    public List<BeanCourseList> getCourse_list() {
        return course_list;
    }

    /**
     * @param course_list the course_list to set
     */
    public void setCourse_list(List<BeanCourseList> course_list) {
        this.course_list = course_list;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
