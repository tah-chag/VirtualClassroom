/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author terence
 */
public class BeanStudentCourse {

    private String fk_course, fk_student;

    /**
     * @return the fk_course
     */
    public String getFk_course() {
        return fk_course;
    }

    /**
     * @param fk_course the fk_course to set
     */
    public void setFk_course(String fk_course) {
        this.fk_course = fk_course;
    }

    /**
     * @return the fk_student
     */
    public String getFk_student() {
        return fk_student;
    }

    /**
     * @param fk_student the fk_student to set
     */
    public void setFk_student(String fk_student) {
        this.fk_student = fk_student;
    }
}
