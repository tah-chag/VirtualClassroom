/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.List;
import model.BeanAssignment;
import model.BeanAssignmentStudent;
import model.BeanLogin;

/**
 *
 * @author terence
 */
public interface ServiceAssignment {

    boolean addAssignment(BeanAssignment a);

    boolean addStudentAssignment(BeanAssignmentStudent a);

    BeanAssignment getAssignment(int id);

    BeanAssignment getAssignment(BeanAssignment a);

    BeanAssignmentStudent getStudentAssignment(BeanAssignmentStudent a);

    List<BeanAssignment> getAssignments();

    List<BeanAssignment> getAssignments(BeanLogin l);

    List<BeanAssignmentStudent> getStudentAssignments();

    List<BeanAssignmentStudent> getStudentAssignments(BeanLogin l);

    List<BeanAssignmentStudent> getStudentAssignments(String student);
}
