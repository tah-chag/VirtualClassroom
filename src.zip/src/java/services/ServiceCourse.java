/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.List;
import model.BeanCourse;
import model.BeanLogin;

/**
 *
 * @author tariro
 */
public interface ServiceCourse {

    boolean addCourse(BeanCourse c);

    boolean delete(String c);

    boolean updateCourse(BeanCourse c);

    int getCount();

    BeanCourse getCourse(String c);

    List<BeanCourse> getCourses();

    List<BeanCourse> getCourses(BeanLogin l);

    List<BeanCourse> getCourses(String p);
}
