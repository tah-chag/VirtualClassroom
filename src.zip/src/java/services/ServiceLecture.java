/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.List;
import model.BeanLecture;
import model.BeanLogin;

/**
 *
 * @author tariro
 */
public interface ServiceLecture {

    boolean addLecture(BeanLecture l);

    BeanLecture getLecture(int id);

    List<BeanLecture> getLectures();

    List<BeanLecture> getLectures(BeanLogin l);

    List<BeanLecture> getLectures(String c);
}
