/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.List;
import model.BeanLecturer;

/**
 *
 * @author tariro
 */
public interface ServiceLecturer {

    boolean addLecturer(BeanLecturer l);

    boolean updateLEcturer(BeanLecturer l);

    BeanLecturer getLecturer(int id);

    BeanLecturer getLecturer(String id);

    List<BeanLecturer> getLecturers();
}
