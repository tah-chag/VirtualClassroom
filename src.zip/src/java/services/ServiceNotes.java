/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.List;
import model.BeanNotes;

/**
 *
 * @author terence
 */
public interface ServiceNotes {

    boolean addNotes(BeanNotes n);

    BeanNotes getNote(int id);

    BeanNotes getNote(BeanNotes n);

    List<BeanNotes> getNotes();

    List<BeanNotes> getNotes(int id);

    List<BeanNotes> getNotesByLecturer(int id);
}
