/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.List;
import model.BeanProgram;

/**
 *
 * @author tariro
 */
public interface ServiceProgram {

    boolean addProgram(BeanProgram p);boolean delete(String c);

    boolean updateProgram(BeanProgram p);

    BeanProgram getProgram(String c);

    List<BeanProgram> getPrograms();
}
