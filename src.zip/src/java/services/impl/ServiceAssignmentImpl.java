/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoAssignment;
import java.util.List;
import model.BeanAssignment;
import model.BeanAssignmentStudent;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceAssignment;

@Transactional(readOnly = true)
@Service("ServiceAssignment")
public class ServiceAssignmentImpl implements ServiceAssignment {

    @Autowired
    private DaoAssignment daoassignemnt;

    @Override
    public boolean addAssignment(BeanAssignment a) {
        return daoassignemnt.addAssignment(a);
    }

    @Override
    public List<BeanAssignment> getAssignments() {
        return daoassignemnt.getAssignments();
    }

    @Override
    public BeanAssignment getAssignment(int id) {
        return daoassignemnt.getAssignment(id);
    }

    @Override
    public BeanAssignment getAssignment(BeanAssignment a) {
        return daoassignemnt.getAssignment(a);
    }

    @Override
    public boolean addStudentAssignment(BeanAssignmentStudent a) {
        return daoassignemnt.addStudentAssignment(a);
    }

    @Override
    public List<BeanAssignmentStudent> getStudentAssignments() {
        return daoassignemnt.getStudentAssignments();
    }

    @Override
    public BeanAssignmentStudent getStudentAssignment(BeanAssignmentStudent a) {
        return daoassignemnt.getStudentAssignment(a);
    }

    @Override
    public List<BeanAssignmentStudent> getStudentAssignments(String student) {
        return daoassignemnt.getStudentAssignments(student);
    }

    @Override
    public List<BeanAssignment> getAssignments(BeanLogin l) {
        return daoassignemnt.getAssignments(l);
    }

    @Override
    public List<BeanAssignmentStudent> getStudentAssignments(BeanLogin l) {
        return daoassignemnt.getStudentAssignments(l);
    }
}
