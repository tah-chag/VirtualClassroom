/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoCourse;
import java.util.List;
import model.BeanCourse;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceCourse;

@Transactional(readOnly = true)
@Service("ServiceCourse")
public class ServiceCourseImpl implements ServiceCourse {

    @Autowired
    private DaoCourse daocourse;

    @Override
    public boolean addCourse(BeanCourse c) {
        return daocourse.addCourse(c);
    }

    @Override
    public BeanCourse getCourse(String c) {
        return daocourse.getCourse(c);
    }

    @Override
    public List<BeanCourse> getCourses() {
        return daocourse.getCourses();
    }

    @Override
    public List<BeanCourse> getCourses(String p) {
        return daocourse.getCourses(p);
    }

    @Override
    public List<BeanCourse> getCourses(BeanLogin l) {
        return daocourse.getCourses(l);
    }

    @Override
    public boolean updateCourse(BeanCourse c) {
        return daocourse.updateCourse(c);
    }

    @Override
    public boolean delete(String c) {
        return daocourse.delete(c);
    }

    @Override
    public int getCount() {
        return daocourse.getCount();
    }

}
