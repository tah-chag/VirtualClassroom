/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoLecture;
import java.util.List;
import model.BeanLecture;
import model.BeanLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceLecture;

@Transactional(readOnly = true)
@Service("ServiceLecture")
public class ServiceLectureImpl implements ServiceLecture {

    @Autowired
    private DaoLecture daolecture;

    @Override
    public boolean addLecture(BeanLecture l) {
        return daolecture.addLecture(l);
    }

    @Override
    public BeanLecture getLecture(int id) {
        return daolecture.getLecture(id);
    }

    @Override
    public List<BeanLecture> getLectures(String c) {
        return daolecture.getLectures(c);
    }

    @Override
    public List<BeanLecture> getLectures() {
        return daolecture.getLectures();
    }

    @Override
    public List<BeanLecture> getLectures(BeanLogin l) {
        return daolecture.getLectures(l);
    }

}
