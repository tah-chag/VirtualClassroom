/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoLecturer;
import java.util.List;
import model.BeanLecturer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceLecturer;

@Transactional(readOnly = true)
@Service("ServiceLecturer")
public class ServiceLecturerImpl implements ServiceLecturer {

    @Autowired
    private DaoLecturer daolecturer;

    @Override
    public boolean addLecturer(BeanLecturer l) {
        return daolecturer.addLecturer(l);
    }

    @Override
    public boolean updateLEcturer(BeanLecturer l) {
        return daolecturer.updateLEcturer(l);
    }

    @Override
    public BeanLecturer getLecturer(int id) {
        return daolecturer.getLecturer(id);
    }

    @Override
    public List<BeanLecturer> getLecturers() {
        return daolecturer.getLecturers();
    }

    @Override
    public BeanLecturer getLecturer(String id) {
        return daolecturer.getLecturer(id);
    }

}
