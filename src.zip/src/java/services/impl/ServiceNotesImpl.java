/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoNotes;
import java.util.List;
import model.BeanNotes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceNotes;

@Transactional(readOnly = true)
@Service("ServiceNotes")
public class ServiceNotesImpl implements ServiceNotes {

    @Autowired
    private DaoNotes daonotes;

    @Override
    public boolean addNotes(BeanNotes n) {
        return daonotes.addNotes(n);
    }

    @Override
    public BeanNotes getNote(int id) {
        return daonotes.getNote(id);
    }

    @Override
    public List<BeanNotes> getNotes() {
        return daonotes.getNotes();
    }

    @Override
    public List<BeanNotes> getNotes(int id) {
        return daonotes.getNotes();
    }

    @Override
    public List<BeanNotes> getNotesByLecturer(int id) {
        return daonotes.getNotesByLecturer(id);
    }

    @Override
    public BeanNotes getNote(BeanNotes n) {
        return daonotes.getNote(n);
    }

}
