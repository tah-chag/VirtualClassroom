/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoProgram;
import java.util.List;
import model.BeanProgram;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceProgram;

@Transactional(readOnly = true)
@Service("ServiceProgram")
public class ServiceProgramImpl implements ServiceProgram {

    @Autowired
    private DaoProgram daoprogram;

    @Override
    public boolean addProgram(BeanProgram p) {
        return daoprogram.addProgram(p);
    }

    @Override
    public BeanProgram getProgram(String c) {
        return daoprogram.getProgram(c);
    }

    @Override
    public List<BeanProgram> getPrograms() {
        return daoprogram.getPrograms();
    }

    @Override
    public boolean updateProgram(BeanProgram p) {
        return daoprogram.updateProgram(p);
    }

    @Override
    public boolean delete(String c) {
       return daoprogram.delete(c);
    }

}
