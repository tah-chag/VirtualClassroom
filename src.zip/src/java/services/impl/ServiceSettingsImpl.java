/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoUser;
import java.util.List;
import model.BeanLogin;
import model.BeanUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceSettings;

@Transactional(readOnly = true)
@Service("ServiceSettings")
public class ServiceSettingsImpl implements ServiceSettings {

    @Autowired
    private DaoUser daouser;

    @Override
    public boolean authenticate(BeanLogin l) {
        return daouser.authenticate(l);
    }

    @Override
    public List<BeanUser> getUsers() {
        return daouser.getUsers();
    }

    @Override
    public boolean addLogin(BeanLogin l) {
        return daouser.addLogin(l);
    }

}
