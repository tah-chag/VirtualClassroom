/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoStudent;
import java.util.List;
import model.BeanStudent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceStudent;

@Transactional(readOnly = true)
@Service("ServiceStudent")
public class ServiceStudentImpl implements ServiceStudent {

    @Autowired
    private DaoStudent daostudent;

    @Override
    public boolean addStudent(BeanStudent s) {
        return daostudent.addStudent(s);
    }

    @Override
    public boolean updateStudent(BeanStudent s) {
        return daostudent.updateStudent(s);
    }

    @Override
    public BeanStudent getStudent(String r) {
        return daostudent.getStudent(r);
    }

    @Override
    public List<BeanStudent> getStudents() {
        return daostudent.getStudents();
    }

}
