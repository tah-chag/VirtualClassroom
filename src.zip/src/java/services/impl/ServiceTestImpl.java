/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services.impl;

import dao.DaoTest;
import java.util.List;
import model.BeanQuestion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import services.ServiceTest;

@Transactional(readOnly = true)
@Service("ServiceTest")
public class ServiceTestImpl implements ServiceTest {

    @Autowired
    private DaoTest daotest;

    @Override
    public boolean addQuestion(BeanQuestion q) {
        return daotest.addQuestion(q);
    }

    @Override
    public BeanQuestion getQuestion(int id) {
        return daotest.getQuestion(id);
    }

    @Override
    public List<BeanQuestion> getQuestions(String course, int q) {
        return daotest.getQuestions(course, q);
    }

    @Override
    public List<BeanQuestion> getQuestions() {
        return daotest.getQuestions();
    }
}
