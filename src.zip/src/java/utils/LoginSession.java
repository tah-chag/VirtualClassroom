/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import config.IMessage;
import static config.IMessage.LOGED_USER;
import static config.IMessage.LOGED_USER_ID;
import static config.IMessage.LOGGED_AUTH;
import static config.IMessage.LOGGED_BEANUSER;
import config.IModel;
import config.IUrl;
import config.PropertiesFiles;
import dao.DaoUser;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import model.BeanLogin;
import model.BeanUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

/**
 *
 * @author tariro
 */
@Repository
@Transactional
public abstract class LoginSession implements IUrl, IMessage, IModel {

    @Autowired
    private DaoUser daouser;
    public BeanUser loggedUser;
    public BeanLogin loggedlogin;
    @Autowired
    public PropertiesFiles case_files;

    /**
     *
     * @param model
     * @param request
     */
    public void setSession(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        try {
            //  System.err.println(session.getAttribute("cloud_id").toString());
            model.addAttribute(LOGED_USER_ID, session.getAttribute("cloud_id"));// rs.getString("id"));
            model.addAttribute(LOGED_USER, session.getAttribute("cloud_user_name"));// rs.getString("last_name"));
            model.addAttribute(LOGGED_AUTH, session.getAttribute("auth_cloud_user").toString());
            BeanUser u = daouser.getUserById(Integer.parseInt(session.getAttribute("cloud_id").toString()));
            model.addAttribute(LOGGED_BEANUSER, u);
            loggedUser = u;
            loggedlogin = daouser.getLogin(Integer.parseInt(session.getAttribute("cloud_id").toString()));
            // System.err.println(u.getSurname());
            BeanUser r = (BeanUser) session.getAttribute("user");
            //  System.err.println(r.getId() + r.getSurname());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
