/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Administrator
 */
@Transactional(readOnly = true)
@Repository
public class UFormatter {

    /**
     * Generate random password
     *
     */
    public String generatePassword() {
        Random r = new Random();
        int x = r.nextInt(1000);
        return String.format("%04d", x);
    }

    /**
     * Output date as YYYY-MM-DD
     *
     */
    public String dateF(String dt) {
        dt = dt.replace("0:00", "");
        try {
            int yr = 0, d = 0, m = 0;
            if (dt.contains("/")) {
                d = Integer.parseInt(dt.substring(0, dt.indexOf("/")));
                m = Integer.parseInt(dt.substring(dt.indexOf("/") + 1, dt.lastIndexOf("/")));
                yr = Integer.parseInt(dt.substring(dt.lastIndexOf("/") + 1));
                return m > 12 ? yr + "-" + d + "-" + m : yr + "-" + m + "-" + d;
            } else if (dt.contains("-")) {
                d = Integer.parseInt(dt.substring(0, dt.indexOf("-")));
                m = Integer.parseInt(dt.substring(dt.indexOf("-") + 1, dt.lastIndexOf("-")));
                yr = Integer.parseInt(dt.substring(dt.lastIndexOf("-") + 1));
                return m > 12 ? yr + "-" + d + "-" + m : yr + "-" + m + "-" + d;
            } else {
                return "0000-00-00";
            }
        } catch (Exception e) {
            return "0000-00-00";
        }
    }

    /**
     * OUPUT date format as YYYY-MM-DD
     *
     */
    public String dateR(String dt) {
        try {
            String yr, d, m;
            yr = dt.substring(dt.lastIndexOf("/") + 1);
            m = dt.substring(dt.indexOf("/") + 1, dt.lastIndexOf("/"));
            d = dt.substring(0, dt.indexOf("/"));
            return yr + "-" + m + "-" + d;
        } catch (Exception e) {
            return dt;
        }
    }

    public String dateD(String dt) {
        try {
            String yr, d, m;
            yr = dt.substring(dt.lastIndexOf("-") + 1);
            m = dt.substring(dt.indexOf("-") + 1, dt.lastIndexOf("-"));
            d = dt.substring(0, dt.indexOf("-"));
            return yr + "/" + m + "/" + d;
        } catch (Exception e) {
            return dt;
        }
    }

    /**
     * Remove (-) character from passwrd
     *
     */
    public String storeReg(String r) {
        return r.replace(" ", "").replace("-", "").toLowerCase();
    }

    public String displayReg(String r) {
        try {
            return r.substring(0, 2) + "-" + r.substring(2, r.length() - 3) + "-" + r.substring(r.length() - 3, r.length() - 2).toUpperCase() + "-" + r.substring(r.length() - 2);
        } catch (Exception e) {
            return r;
        }
    }

    /**
     * Generate branch code
     *
     */
    /**
     * generate duns number
     *
     */
    public String generateDuns(Connection c, int et) {
        //Duns No. format, dummy starting numbers: ZF-000-0001 - individuals, 16-000-0001 -companies
        //org.apache.commons.lang.StringUtils.leftPad(String str, int size, '0')
        int x = 0;
        String sql = et == 1 ? "SELECT count(*)+1 FROM fincheck.m_company  where left(duns_number,2)=16"
                : "SELECT count(*)+1 FROM fincheck.m_individual where left(duns_number,2)='ZF'";
        try {
            Statement st = c.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                x = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        String dnns = String.format("%07d", x);
        dnns = (et == 1 ? "16" : "ZF") + "-" + dnns.substring(0, 3) + "-" + dnns.substring(3);
        return dnns;
    }
    /**
     * Generate CB number
     *
     */

    /**
     * Generate claim number
     *
     */
}
